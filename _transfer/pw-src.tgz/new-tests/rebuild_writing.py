"""Rebuild content/writing/task1.json and task2.json into a clean state.

Run from the repo root:  python3 new-tests/rebuild_writing.py
Reads the CURRENT files (which must be the 24 Sep 2026 versions), writes /tmp/*.new.json.
"""
import json, re

R = 'content/writing/'
T1 = {t['id']: t for t in json.load(open(R + 'task1.json'))}
T2 = {t['id']: t for t in json.load(open(R + 'task2.json'))}

FIX = [('pover ty', 'poverty'), ('tr affic', 'traffic'), ('Discu ss', 'Discuss'), (' a nd ', ' and '),
       ('o utweigh', 'outweigh'), ('sentenc e', 'sentence'), ('di sagree', 'disagree'),
       ('disad vantages', 'disadvantages'), ('expl anations', 'explanations'), ('experie ncing', 'experiencing'),
       ('versa tile', 'versatile'), ('dail y', 'daily'), (' th e ', ' the '), ('activit ies', 'activities'),
       ('balan ced', 'balanced'), ('power s', 'powers'), ('a mong', 'among'), ('migrat ion', 'migration'),
       ('language s', 'languages'), ('Ozo ne', 'Ozone'), ('Altho ugh', 'Although'), ('w ater', 'water'),
       ('co mmunication', 'communication'), ('o n-line', 'on-line'), ('w ritten', 'written'),
       ('substi tute', 'substitute'), ('hig hly', 'highly'), ('opportunit ies', 'opportunities'),
       ('ea sily', 'easily'), ('fe el', 'feel'), ('sills', 'skills'), ('Tarde', 'Trade'), ('ha ve', 'have')]


def fx(s):
    for a, b in FIX:
        s = s.replace(a, b)
    s = re.sub(r'(\w) -(\w)', r'\1-\2', s)
    s = re.sub(r'(\w)- (\w)', r'\1-\2', s)
    s = re.sub(r'\s+([?.,!])', r'\1', s)
    s = re.sub(r'\s{2,}', ' ', s)
    return s.strip()


def topic(id, name, prompts, ideas=None, links=None, sampleText=None, sampleImages=None):
    t = {'id': id, 'topic': name, 'prompts': [fx(p) for p in prompts], 'minutes': 40, 'minWords': 250}
    if ideas:
        t['ideas'] = [fx(i) for i in ideas if i and i.strip()]
    if links:
        t['links'] = links
    if sampleText:
        t['sampleText'] = sampleText
    if sampleImages:
        t['sampleImages'] = sampleImages
    return t


g = lambda i: T2[i]
out = []
out.append(topic('w2-01', 'Genetically Modified Food', g('w2-01')['prompts'], g('w2-01')['ideas'][1:], g('w2-01')['links']))
p = g('w2-02')['prompts']
out.append(topic('w2-02', 'Artificial Intelligence', [p[0], p[1].split(' https://')[0]], None, g('w2-02')['links']))
p = g('w2-03')['prompts']
out.append(topic('w2-03', 'Animal Rights and Testing', p[:4]))
out.append(topic('w2-36', 'Unemployment', p[4:8]))
p = g('w2-04')['prompts']
out.append(topic('w2-04', 'Poverty', p[:3]))
out.append(topic('w2-37', 'Air Pollution', [
    'Some people say that restricting air travel is the only way to prevent air pollution. Others believe that individuals should do something about it. Discuss both views and give your opinion.',
    'Environmental pollution is the biggest disaster. What are the causes of this problem and what are the solutions?',
    p[6], p[7]]))
p = g('w2-05')['prompts']
out.append(topic('w2-05', 'Water Pollution', [p[0], p[1], p[2].replace('while others it should', 'while others think it should')], g('w2-05')['ideas']))
p = g('w2-06')['prompts']
I = g('w2-06')['ideas']
out.append(topic('w2-06', 'Music', [
    'There are many different types of music in the world today. Why do we need music? Is the traditional music of a country more important than the international music that is heard everywhere nowadays?',
    p[1].replace('MUSIC & SOCIETY / PROS CONS Statement : ', ''), p[3]],
    [I[0], 'Model introduction: ' + p[0].split('own opinion. ')[1]]))
out.append(topic('w2-38', 'Road Safety', [p[4].replace('Do you agree ?', 'Do you agree or disagree?'), p[5], p[6].split(' • ')[0]], I[1:4]))
p = g('w2-08')['prompts']
I = g('w2-08')['ideas']
out.append(topic('w2-08', 'Stress', [p[0], I[6] + ' ' + p[1], p[2]], I[0:6]))
out.append(topic('w2-39', 'Rich and Poor Countries', [
    p[3], p[4], 'Rich countries should help poor countries. Do you agree or disagree?',
    p[5].split(' OR ')[1], p[6], p[7]], I[7:9], g('w2-08').get('links')))
p = g('w2-11')['prompts']
I = g('w2-11')['ideas']
out.append(topic('w2-11', 'Migration and Brain Drain', [p[0].split(' Or ')[0], p[1]], I[0:7], g('w2-11')['links']))
out.append(topic('w2-40', 'Online Learning', p[2:5], I[7:10]))
t = g('w2-14')
p = t['prompts']
I = t['ideas']
out.append(topic('w2-14', 'Globalisation', [p[0].replace(' Positive how?', ''), p[1], p[2], p[3].split(' Topic 5')[0]],
                 [I[0], I[1].replace(' Negative how?', '')] + I[2:7]))
out.append(topic('w2-41', 'Solar Energy', [
    'Solar energy is becoming more and more popular as a source of household energy in many countries around the world. Why is this? What are the advantages and disadvantages of solar energy?'],
    I[7:11], None, t['sampleText']))
out.append(topic('w2-42', 'Global Warming', [p[4]], I[11:32]))
t = g('w2-17')
I = t['ideas']
parts = I[2].split(' SAMPLE ANSWER ')
out.append(topic('w2-17', 'Internet and Communication', t['prompts'], [I[0], I[1], parts[0]], None, 'SAMPLE ANSWER\n\n' + fx(parts[1])))
t = g('w2-18')
p = t['prompts']
out.append(topic('w2-18', 'Health', [p[0].replace('STATEMENT 1 : ', ''), p[1].replace('Statement 2. ', '')], t['ideas']))
out.append(topic('w2-23', 'Trade', g('w2-23')['prompts'], g('w2-23')['ideas']))
t = g('w2-24')
p = t['prompts']
s2 = p[1].split(' Statement 2 ')
out.append(topic('w2-24', 'Work and Careers', [p[0].replace('Statement 1: ', ''), s2[1].split(' Statement 3 ')[0], s2[1].split(' Statement 3 ')[1]],
                 t['ideas'] + [s2[0]]))
t = g('w2-25')
p = t['prompts']
I = t['ideas']
out.append(topic('w2-25', 'Tourism', [p[0], p[1], p[2], p[3].split(' Topic 9')[0]], I[0:5]))
out.append(topic('w2-43', 'History of Houses', [
    'In some countries, more and more people are becoming interested in finding out about the history of the house or building they live in. What are the reasons for this? How can people research this?'], I[5:7]))
t = g('w2-27')
p = t['prompts']
I = t['ideas']
out.append(topic('w2-27', 'House or Apartment', [I[0].split(' Benefits of House')[0]], ['Benefits of a house: ' + I[1], I[2], I[3], p[0]]))
out.append(topic('w2-44', 'Building Design', [p[1]]))
t = g('w2-30')
out.append(topic('w2-30', 'Hunger and Food Supply', [
    'In spite of the advances made in agriculture, many people around the world still go hungry. Why is this the case? What can be done about this problem?'], None, None, t['sampleText']))
out.append(topic('w2-35', 'Advertising', [
    "People's lives are now surrounded by advertisements. This affects what people consider important and has a negative impact on people's lives. Do you agree or disagree?"]))
strip = lambda s: re.split(r' Give reasons for your answer', s)[0].strip()
for old, new, name in [('w2x-15', 'w2-45', 'Talent and Training'), ('w2x-40', 'w2-46', 'Driverless Vehicles'), ('w2x-43', 'w2-47', 'Museum Admission Charges')]:
    t = g(old)
    out.append(topic(new, name, [strip(t['prompts'][0])], None, None, t.get('sampleText'), t.get('sampleImages')))
t = g('w2x-42')
out.append(topic('w2-48', 'Young and Old Populations', [strip(t['prompts'][0])], None, None, None, ['t1-42.jpg']))

s26 = T1['w1-26']['sampleText']
cut = s26.find('ESSAY SAMPLE WRITING TASK 2')
new2 = [
    ('w2-50', 'Children and Toys', 'Some parents buy their children a large number of toys to play with. What are the advantages and disadvantages for the child of having a large number of toys?', None, ['t1-04.jpg']),
    ('w2-51', 'Foreign Languages at Primary School', 'Some experts believe that it is better for children to begin learning a foreign language at primary school rather than secondary school. Do the advantages of this outweigh the disadvantages?', None, ['t1-07.jpg']),
    ('w2-52', 'Telling Children They Can Achieve Anything', 'In some cultures, children are often told that they can achieve anything if they try hard enough. What are the advantages and disadvantages of giving children this message?', T1['w1-08'].get('sampleText'), ['t1-09.jpg', 't1-10.jpg']),
    ('w2-53', 'Child Labour', 'Nowadays, child labour has become a major concern. Why is it so? What can be done to solve this problem?', None, None),
    ('w2-54', 'Taking Risks', 'It is important for people to take risks, both in their personal and professional lives. Do you think the advantages of taking risks outweigh the disadvantages?', None, ['t1-13.jpg']),
    ('w2-55', 'Problems of Big Cities', 'People living in large cities have to face many problems in everyday life. What are those problems? Should the government encourage people to move to regional towns?', s26[cut:] if cut > 0 else None, ['t1-19.jpg']),
    ('w2-56', 'Foreign Films and TV', 'Some people think that it is good for a country’s culture to import foreign movies and TV programmes. Others think that it is better to produce these locally. Discuss both views and give your opinion.', None, None),
    ('w2-57', 'Companies and Communities', 'Companies should provide sports and social facilities to local communities. Do you agree or disagree?', None, None),
    ('w2-58', 'Life Now and 100 Years Ago', 'Life now is better than it was 100 years ago. To what extent do you agree or disagree with this statement?', None, ['t1-29.jpg']),
    ('w2-59', 'Travel, Media and Other Cultures', 'The ease of international travel and the spread of various kinds of mass media all over the world have made it more possible than ever for people to know how other people live in other countries. Do the advantages of this development outweigh the disadvantages?', None, None),
    ('w2-60', 'Printed Books in the Digital Age', 'Some people believe that printed books are no longer necessary in this digital era as all writings can be stored electronically. Others think that printed books still play an important role. Discuss both views and give your opinion.', None, None),
]
for id, name, pr, st, si in new2:
    out.append(topic(id, name, [pr], None, None, st, si))
json.dump(out, open('/tmp/task2.new.json', 'w'), ensure_ascii=False, indent=1)

# ---------------- Task 1 ----------------
def e(id, title, images, base=None, **kw):
    t = {'id': id, 'title': title, 'images': images, 'minutes': 20, 'minWords': 150}
    if base:
        for k in ('sampleText', 'sampleImages'):
            if k in T1[base]:
                t[k] = T1[base][k]
    t.update(kw)
    for k in [k for k, v in t.items() if v is None]:
        del t[k]
    return t


L = []
L.append(e('w1-02', 'The tables below give information about sales of Fairtrade-labelled coffee and bananas in 1999 and 2004 in five European countries.', ['t1-02.jpg'], 'w1-02'))
L.append(e('w1-05', 'The table below shows the worldwide market share of the notebook computer market for manufacturers in the years 2006, 2007 and 2014.', ['t1-05.jpg'], 'w1-05'))
L.append(e('w1-08', 'The table below gives information about the problems faced by children in two primary schools in 2005 and 2015.', ['t1-08.jpg']))
L.append(e('w1-11', 'The table and bar chart below show the time spent on leisure and household activities by men and women.', ['t1-11.jpg']))
L.append(e('w1-12', 'The table below gives information about changes in modes of travel in England between 1985 and 2000.', ['t1-12.jpg']))
L.append(e('w1-14', 'The table below gives information on consumer spending on different items in five different countries in 2002.', ['t1-14.jpg'], None,
           sampleText=T1['w1-12'].get('sampleText'), sampleImages=['t1-16.jpg']))
L.append(e('w1-20', 'The charts below show the growth in the population in some of the world’s largest cities as well as the population distribution in urban and rural areas.', ['t1-20.jpg'], 'w1-20'))
L.append(e('w1-22', 'The tables below give information about the consumption and production of potatoes in five parts of the world in 2006.', ['t1-22.jpg']))
L.append(e('w1-23', 'The table below shows the fishing industry in a European country according to four indicators.', ['t1-23.jpg']))
L.append(e('w1-24', 'The table below shows the proportion of different categories of families living in poverty in Australia in 1999.', ['t1-24.jpg']))
L.append(e('w1-25', 'The chart below shows the amount of money per week spent on fast foods in Britain. The graph shows the trends in consumption of fast foods.', ['t1-25.jpg']))
L.append(e('w1-26', 'The table below describes the number of employees and factories in England and Wales from 1851 to 1901.', ['t1-26.jpg'], None,
           sampleText=(s26[:cut].strip() if cut > 0 else s26), sampleImages=['t1-27.jpg']))
L.append(e('w1-28', 'The chart below shows the cost-of-living averages in two different cities as compared to the national cost-of-living average.', ['t1-28.jpg'], None, sampleImages=['t1-29.jpg']))
L.append(e('w1-30', 'The table below gives information about the five small companies in Britain that came top in a survey of staff conducted by a national newspaper to find out which companies are the best to work for.', ['t1-30.jpg']))
L.append(e('w1-31', 'The table below shows the number of mobile phones and personal computers per 1,000 people in 2003 in six different countries.', ['t1-31.jpg']))
L.append(e('w1-34', 'The table below shows the number of people taking part in a wildlife survey in Britain between 2001 and 2009.', ['t1-34.jpg']))
L.append(e('w1-35', 'The table below describes the changes in the number of people who went for international travel in 1990, 1995, 2000 and 2005 (millions).', ['t1-35.jpg']))
L.append(e('w1-36', 'The table below shows the population of three cities in 1990, the population forecast for 2000 (made in 1990), and the actual population in 2000.', ['t1-36.png']))
L.append(e('w1-37', 'The table below shows the number of cars made in three countries in 2003, 2006 and 2009.', ['t1-37.jpg']))
L.append(e('w1-38', 'The plans below show an art gallery in Australia in 1950 and now.', ['t1-38.png']))
L.append(e('w1-39', 'The table below provides information on marriage status and age from 1960 to 2000 in Australia.', ['t1-39.png']))
for i in range(40, 59):
    L.append(T1[f'w1-{i}'])
L.append(e('w1-59', 'The table below shows expenditure on advertising by four car companies in the United Kingdom in 2002.', ['t1-carads.jpg']))
L.append(e('w1-60', 'The table below shows the percentage of adults in urban and rural areas who took part in four free-time activities in 1990 and 2010.', ['t1-urbanrural.jpg']))
L.append(e('w1-61', 'The table below presents weekly food consumption per person in a European country in 1992, 2002 and 2012.', ['t1-foodweekly.jpg']))
L.append(e('w1-63', 'The table below shows the percentage of people unemployed in the total labour force across nine countries in 1994 and 2004.', ['t1-unemployment.jpg']))
L.append(e('w1-64', 'The table below shows the percentage of working men and women in different areas of employment in one country in 1986, 1996 and 2006.', ['t1-employment.jpg']))
L.append(e('w1-65', 'The chart below gives information about the number of books rented in a British local library in 2009.', ['t1-librarybooksrented.png']))
L.append(e('w1-66', 'The chart below shows the different levels of post-school qualifications in Australia and the proportion of men and women who held them in 1999.', ['t1-postschoolqualificationsaustralia.png']))
json.dump(L, open('/tmp/task1.new.json', 'w'), ensure_ascii=False, indent=1)
print('task1', len(L), 'task2', len(out))

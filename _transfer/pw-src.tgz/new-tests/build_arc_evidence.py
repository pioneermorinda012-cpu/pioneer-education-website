"""Hand-checked evidence for the letter answers in ar-c1 … ar-c5.

find-evidence.py already wrote the gap-fill lines (exact) and NOT GIVEN (none).
This adds the matching / TFNG / multiple-choice / heading lines it could not
place, and replaces its 'closest line' guesses with the checked sentence.
Every needle is searched for inside ONE paragraph, because the Player marks a
paragraph at a time. Nothing is written if any needle is missing.
"""
import json, re, html

def plain(x):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', str(x)))).strip()

def sentences(t):
    return re.split(r'(?<=[.?!’\'”])\s+(?=[A-Z‘\'“(])', t)

N = {
'ar-c1': {
 1: ['years of intensive book learning that are now common in modern society'],
 2: ['In contrast to the general undereducation and illiteracy of the times'],
 11: ['the ability to screen out harmful ultraviolet and infrared rays from the sun'],
 12: ['Although they are a source of much revenue'],
 13: ['despite the growth of such surgery'],
 14: ['the absurdity of having an undereducated American ruffian'],
 15: ['The subtitlers need to be aware of this in order to translate true meaning'],
 16: ['Although these themes are universal'],
 17: ['an Italian word referring to a variation of the central card game'],
 18: ['they insert a blander and inappropriate term', 'An even clearer subtitling lapse'],
 21: ['only in such minimal and unlikely situations does this strategy become acceptable'],
 23: ['This is the strategy of Transfer'],
 24: ['The strategy used is thus Paraphrasing'],
 25: ['using the strategy known as Condensation'],
 26: ['so the strategy used here is Resignation'],
 29: ['the fact that he was a meteorologist'],
 30: ['the theory needed evidence of a propulsive force'],
 31: ['by being consistent and essentially unstoppable'],
 32: ['anomalously hot areas of interior rock'],
 36: ['whereas the periodic earthquakes along California'],
},
'ar-c2': {
 1: ['Looking at the sources of some common spices'],
 2: ['From then on, spices were the driving force of the world economy'],
 3: ['At first, Portugal was the dominant power'],
 4: ['But why were spices always in such demand?'],
 5: ['Predictably, the majority of the world'],
 6: ['In contrast, whole dried spices retain these for much longer'],
 10: ['The ever-popular masala, as noted, could be anything'],
 11: ['became the major impetus to exploration and conquest'],
 13: ['which can be packaged and stored well'],
 14: ['lowly-organised creatures', 'in their untold millions'],
 15: ['basically a slimy, muscular, moist, segmented tube'],
 16: ['to either travel more quickly through the open air'],
 17: ['the weight of earthworms beneath the soil is often greater'],
 27: ['Organisations, also, are analogous to organisms'],
 28: ['It thus seems strange to argue that conflict is not necessarily unwelcome'],
 29: ['Clearly, this is not a method likely to optimise the chances'],
 30: ['very low levels or an absence of conflict may actually be worrying'],
},
'ar-c3': {
 10: ['This combination immediately made nitro less dangerous to handle'],
 11: ['Yet the obituary was harsh and condemning'],
 13: ['Few consider that all that money comes from'],
 14: ['segregation of some sort happens all the time'],
 15: ['research often sinks into a morass of conflicting data'],
 16: ['Proponents of separating the genders often argue'],
 17: ['do not support the claims of superior results or persistent gender differences'],
 18: ['Supporters of co-education argue that positive and co-operative interaction'],
 19: ['still constitutes education, and of a vital nature'],
 20: ['do not support the claims of superior results or persistent gender differences'],
 21: ['published and endorsed by several respected magazines'],
 22: ['receive more deference and respect from society'],
 23: ['the current interest in single-gender schooling is somewhat surprising'],
 24: ['it may simply be an idealistic illusion'],
 25: ['the higher quality of the teachers'],
 26: ['This is the most important point, and would determine my choice'],
 31: ['Some of them have also suggested that the discovery of farming'],
 32: ['Subsequent scholars were able to confirm this'],
 33: ['This is often done with nationalistic overtones'],
 34: ['thus they remain skeptical over such a claim'],
 35: ['One interesting theory posited by geologists'],
 40: ['Still, the implications are mind-boggling'],
},
'ar-c4': {
 5: ['pigment production was a meticulous and time-consuming process'],
 6: ['The pigment which results is also stronger and longer-lasting'],
 8: ['this has seen a resurgence in the popularity of cochineals'],
 14: ['it is this fluid (and not their blood) which may contain'],
 16: ['passing away in Egypt and Greece, respectively'],
 17: ['It infects over two million people a year'],
 18: ['Unlike malaria, there exists a vaccine'],
 27: ['located deep in the middle of the Venezuelan jungle'],
 28: ['Other more abrupt causes of waterfalls are earthquakes or landslides'],
 30: ['if each step is larger still'],
 31: ['Giant falls, such as Niagara, are graded at the very top of this scale'],
},
'ar-c5': {
 1: ['Deep-sea fish and whales have little or no light'],
 2: ['our mammalian ancestors probably only managed to survive at all'],
 3: ['But the daytime economy is already heavily exploited by other creatures'],
 4: ['has come from applying radar theory to them'],
 5: ['weapons designers adapted it for the detection of submarines'],
 14: ['At the height of the Roman Empire, nine major systems'],
 15: ['Preventable water-related diseases kill an estimated'],
 16: ['More than 20% of all freshwater fish species are now threatened'],
 17: ['Some water experts are now demanding that existing infrastructure be used in smarter ways'],
 18: ['the demand for water is not rising as rapidly as some predicted'],
 19: ['Two factors: people have figured out how to use water more efficiently'],
 20: ['But such projects must be built to higher specifications'],
 21: ['with as much water per person as is provided in many parts of the industrial world today'],
 22: ['mainly because of the expansion of artificial irrigation systems'],
 24: ['the rate at which people withdraw water from aquifers, rivers and lakes has slowed'],
 25: ['thanks to a range of new technologies that help to conserve water in homes and industry'],
 27: ['is a book which looks at radical new approaches to learning'],
 28: ['we will find it easier to recall peripheral details'],
 29: ['If we think of a lecture we listened to with great concentration'],
 30: ['consciousness is shifted away from the curriculum'],
 31: ['In the second part, they listen to baroque music'],
 32: ['they develop an expectation that learning will be easy and pleasant'],
 33: ['Such methods are not unusual in language teaching'],
 36: ['students can regularly learn 1000 new words'],
 39: ['While suggestopedia has gained some notoriety'],
 40: ['few teachers are able to emulate the spectacular results'],
},
}

bad = []
out = {}
for pid, rows in N.items():
    t = json.load(open(f'content/tests/{pid}.json'))
    ev = json.load(open(f'content/evidence/{pid}.json'))
    key = json.load(open(f'content/keys/{pid}.json'))
    for q, needles in rows.items():
        sec = next(i for i, s in enumerate(t['sections']) if q in s['qs'])
        paras = [plain(p['t'] if isinstance(p, dict) else p) for p in t['sections'][sec]['passage']['paras']]
        lines = []
        for n in needles:
            hit = [x for p in paras for x in sentences(p) if n in x]
            if not hit: bad.append((pid, q, n)); continue
            if hit[0] not in lines: lines.append(hit[0])
        a = (key[str(q)].get('accept') or key[str(q)].get('any'))[0]
        if re.fullmatch(r'NOT ?GIVEN', a, re.I): bad.append((pid, q, 'is NOT GIVEN')); continue
        ev[str(q)] = {'s': sec, 't': lines}
    out[pid] = ev
if bad:
    for b in bad: print('PROBLEM', b)
    raise SystemExit(1)
for pid, ev in out.items():
    json.dump(dict(sorted(ev.items(), key=lambda kv: int(kv[0]))), open(f'content/evidence/{pid}.json', 'w'), ensure_ascii=False, indent=1)
    print(pid, len(ev), 'evidence entries')

"""Repair questions whose key can never match what the Player submits.

The Player sends, for a string option list, the POSITION letter (a, b, c…).
Some imported GT papers keyed those questions with the option TEXT ("vii",
"aluminium drink can", "28"), so no student could ever be marked right.

  * short labels (roman numerals, page numbers) -> the options become
    {l: label, t: label}, so the button shows the label and submits it
  * longer option texts -> the key becomes the letter, display keeps the words

NOT GIVEN answers whose evidence cites a line are switched to the no-line form
(k: "none"), which the review explains properly.

Dry run by default; pass --write to change files. Backups go to new-tests/_backup/.
"""
import json, glob, os, re, sys, shutil

WRITE = '--write' in sys.argv
L = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
norm = lambda v: re.sub(r'[^a-z0-9]', '', str(v).lower())
changes = []

def fix_paper(pid):
    tp, kp = f'content/tests/{pid}.json', f'content/keys/{pid}.json'
    t, k = json.load(open(tp)), json.load(open(kp))
    t_changed = k_changed = False
    for s in t['sections']:
        for g in s['groups']:
            for q in g.get('questions', []) or []:
                owner = q if q.get('opts') else g
                opts = owner.get('opts')
                if not opts or not all(isinstance(o, str) for o in opts):
                    continue
                n = str(q['n'])
                key = k.get(n)
                if not key: continue
                field = 'any' if 'any' in key else 'accept'
                letters = [L[i] for i in range(len(opts))]
                vals = key[field]
                if all(norm(v) in map(norm, letters) for v in vals):
                    continue  # already letters
                texts = [norm(o) for o in opts]
                if not all(norm(v) in texts for v in vals):
                    changes.append((pid, n, 'UNRESOLVED', vals, opts)); continue
                if all(len(str(o).strip()) <= 4 for o in opts):
                    owner['opts'] = [{'l': o, 't': o} for o in opts]
                    t_changed = True
                    changes.append((pid, n, 'labels', vals))
                else:
                    new = [letters[texts.index(norm(v))] for v in vals]
                    key[field] = new
                    if field == 'accept':
                        key['display'] = f"{new[0]} — {opts[texts.index(norm(vals[0]))]}"
                    else:
                        key['display'] = ', '.join(new) + (key['display'][key['display'].find('  ('):] if '  (' in key['display'] else '')
                    k_changed = True
                    changes.append((pid, n, 'letters', vals, '->', new))
    # evidence
    ep = f'content/evidence/{pid}.json'
    e_changed = False
    if os.path.exists(ep):
        ev = json.load(open(ep))
        for n, e in ev.items():
            kk = k.get(n)
            is_ng = kk and 'accept' in kk and re.fullmatch(r'NOT ?GIVEN', str(kk['accept'][0]), re.I)
            if is_ng and e.get('k') != 'none':
                changes.append((pid, n, 'NG evidence -> none', e.get('t')))
                ev[n] = {'s': e['s'], 't': [], 'k': 'none'}; e_changed = True
            elif not is_ng and e.get('k') != 'none' and not e.get('t'):
                changes.append((pid, n, 'empty evidence removed', kk))
                del ev[n]; e_changed = True
                break
    if WRITE:
        os.makedirs('new-tests/_backup', exist_ok=True)
        for path, changed, data in ((tp, t_changed, t), (kp, k_changed, k)):
            if changed:
                shutil.copy(path, f'new-tests/_backup/{os.path.basename(os.path.dirname(path))}-{os.path.basename(path)}')
                json.dump(data, open(path, 'w'), ensure_ascii=False, indent=1)
        if e_changed:
            shutil.copy(ep, f'new-tests/_backup/evidence-{pid}.json')
            json.dump(ev, open(ep, 'w'), ensure_ascii=False, indent=1)

for f in sorted(glob.glob('content/keys/*.json')):
    fix_paper(os.path.basename(f)[:-5])
for c in changes: print(*c)
print(len(changes), 'changes', '(written)' if WRITE else '(dry run)')

"""Answer keys + evidence for P1R2–P1R6 (Academic Reading, Practice Tests Plus 1).

Every answer was worked out against the paper's own passage and questions.
Evidence is found by NEEDLE (a short verbatim phrase) and the whole sentence is
copied from the passage, so an explanation can never drift from what students read.
The script refuses to write anything if a needle is not found.

  exact  gap-fill answers copied from the passage
  (none) hand-checked letter answers (headings, matching, TFNG, MCQ)
  none   NOT GIVEN — deliberately no line

Run from repo root:  python3 new-tests/build_reading_keys.py
"""
import json, re, html

def plain(x):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', str(x)))).strip()

def sentences(text):
    return re.split(r'(?<=[.?!’\'”])\s+(?=[A-Z‘\'“(])', text)

NG = None  # marker for NOT GIVEN

# (q, accept list, display, section, needles or NG, kind)  kind: 'x' exact / '' letter
PAPERS = {
'p1r2': [
 (1, ['vi'], 'vi', 0, ['In the 1960s a young American research psychologist', 'these mistakes are systematic and predictable'], ''),
 (2, ['ix'], 'ix', 0, ['Once a figure has been mentioned', 'The asking price quoted in a house sale'], ''),
 (3, ['iii'], 'iii', 0, ['No one likes to abandon a cherished belief'], ''),
 (4, ['viii'], 'viii', 0, ['put a lot of emphasis on things they have seen and experienced themselves', 'invest only within the country they live in'], ''),
 (5, ['i'], 'i', 0, ['people spend proportionally too much time on small decisions', 'planning their office party'], ''),
 (6, ['iv'], 'iv', 0, ['crying over spilled milk is not just a waste of time'], ''),
 (7, ['D'], 'D', 0, ['the idea of applying psychological insights to economics and business decisions was seen as rather bizarre'], ''),
 (8, ['B'], 'B', 0, ['Surveys have shown that people', 'The same goes for their hopes of ever-rising prices for their homes'], ''),
 (9, ['D'], 'D', 0, ['No one likes to abandon a cherished belief', 'may find it difficult to admit they have made a mistake'], ''),
 (10, ['A'], 'A', 0, ['too much emphasis on information close at hand'], ''),
 (11, ['managers and sportsmen', 'managers sportsmen', 'sportsmen and managers', 'sportsmen managers', 'managers or sportsmen'], 'managers (and) sportsmen', 0, ['Such optimism can be useful for managers or sportsmen'], 'x'),
 (12, ['driving'], 'driving', 0, ['below-average skills in, say, driving'], 'x'),
 (13, ['pharmaceutical companies', 'pharmaceutical company', 'pharmaceutical'], 'pharmaceutical companies', 0, ['Pharmaceutical companies, which are accustomed to many failures'], 'x'),
 (14, ['TRUE'], 'TRUE', 1, ['merely as more profitable versions of Victorian lantern shows'], ''),
 (15, ['FALSE'], 'FALSE', 1, ['merely as more profitable versions of Victorian lantern shows', 'Then the best of the pioneers looked beyond'], ''),
 (16, ['NOT GIVEN'], 'NOT GIVEN', 1, NG, ''),
 (17, ['TRUE'], 'TRUE', 1, ['D W Griffith in California glimpsed its grace'], ''),
 (18, ['FALSE'], 'FALSE', 1, ['It never occurred to its financial backers'], ''),
 (19, ['D'], 'D', 1, ['without soundtracks'], ''),
 (20, ['F'], 'F', 1, ['are regularly voted among the best ever made in the country'], ''),
 (21, ['B'], 'B', 1, ['they addressed social and peasant themes in an optimistic and romantic way'], ''),
 (22, ['H'], 'H', 1, ['in Tokyo the director chose the stories and hired the producer and actors'], ''),
 (23, ['E'], 'E', 1, ['were constrained by the society of the time'], ''),
 (24, ['A'], 'A', 1, ['often retreating at moments of confrontation or strong feeling'], ''),
 (25, ['G'], 'G', 1, ['His camera seldom moved'], ''),
 (26, ['B'], 'B', 1, ['it is the beliefs which underlie cultures such as those of China and Japan'], ''),
 (27, ['G'], 'G', 2, ['It emerges from the factory rolled, like a carpet'], ''),
 (28, ['D'], 'D', 2, ['His secret is a special mould', 'a surface smoother than anything'], ''),
 (29, ['J'], 'J', 2, ['The success of Kuijpers’ design will depend on how much it eventually costs'], ''),
 (30, ['B'], 'B', 2, ['road builders have to spend money erecting sound barriers', 'Houses become harder to sell'], ''),
 (31, ['I'], 'I', 2, ['On large highways, trucks tend to use the inside lane'], ''),
 (32, ['C'], 'C', 2, ['He set out to tackle the three most important factors'], ''),
 (33, ['asphalt'], 'asphalt', 2, ['Hot asphalt, mixed with small stones'], 'x'),
 (34, ['9', 'nine'], '9', 2, ['about 9 millimetres'], 'x'),
 (35, ['concrete'], 'concrete', 2, ['It consists of a sound-absorbing concrete base'], 'x'),
 (36, ['E'], 'E', 2, ['the surface can absorb any air that is passing through a tyre’s tread'], ''),
 (37, ['J'], 'J', 2, ['they make it easier for the water to drain away'], ''),
 (38, ['G'], 'G', 2, ['the energy of the sound dissipates into the concrete as heat'], ''),
 (39, ['C'], 'C', 2, ['This flow will help flush out waste material'], ''),
 (40, ['A'], 'A', 2, ['it is possible to control which frequencies the concrete absorbs'], ''),
],
'p1r3': [
 (1, ['B'], 'B', 0, ['the brain is better at holding onto information than it is at knowing what information is important'], ''),
 (2, ['A'], 'A', 0, ['superficial, repetitive pop tunes are, by their very nature, more likely to stick'], ''),
 (3, ['D'], 'D', 0, ['Brain imaging studies showed that this activated the same region'], ''),
 (4, ['E'], 'E', 0, ['remembered the words better than those who simply read them'], ''),
 (5, ['D'], 'D', 0, ['in which people remember musical phrases as a single unit of memory'], ''),
 (6, ['F'], 'F', 0, ['Before the written word could be used to record history, people memorised it in songs'], ''),
 (7, ['B'], 'B', 0, ['But it can become fatigued or depressed'], ''),
 (8, ['I'], 'I', 0, ['This message functions to unite society'], ''),
 (9, ['G'], 'G', 0, ['Particular chunks may be especially'], ''),
 (10, ['E'], 'E', 0, ['The more you try to suppress a thought, the more you get it'], ''),
 (11, ['D'], 'D', 0, ['The annoying playback probably originates in the auditory cortex'], ''),
 (12, ['A'], 'A', 0, ['You hear a pop song on the radio'], ''),
 (13, ['F'], 'F', 0, ['so I will not play them in the early morning'], ''),
 (14, ['NOT GIVEN'], 'NOT GIVEN', 1, NG, ''),
 (15, ['YES'], 'YES', 1, ['Admittedly, there may be political or social barriers to achieving a rich world'], ''),
 (16, ['NO'], 'NO', 1, ['we ought to start by asking what people want'], ''),
 (17, ['YES'], 'YES', 1, ['Increasing productivity that results in decreasing costs for such goods'], ''),
 (18, ['NOT GIVEN'], 'NOT GIVEN', 1, NG, ''),
 (19, ['YES'], 'YES', 1, ['their rising prices may compel industrial society'], ''),
 (20, ['agriculture'], 'agriculture', 1, ['the increasing amount of land consumed by agriculture'], 'x'),
 (21, ['parks'], 'parks', 1, ['more land in the US has been set aside in parks'], 'x'),
 (22, ['productivity'], 'productivity', 1, ['world food productivity'], 'x'),
 (23, ['protein'], 'protein', 1, ['adequate supplies of animal protein'], 'x'),
 (24, ['DNA'], 'DNA', 1, ['Once their DNA has been extracted'], 'x'),
 (25, ['game'], 'game', 1, ['game such as wild deer, rabbits and wild ducks will be ever more abundant'], 'x'),
 (26, ['A'], 'A', 1, ['particularly if its members choose to live widely dispersed'], ''),
 (27, ['D'], 'D', 1, ['our aircraft and cars will be piloted by computers'], ''),
 (28, ['E'], 'E', 2, ['studied the technology once used by Polynesians to colonize islands'], ''),
 (29, ['B'], 'B', 2, ['archaeologists will someday study off-Earth sites'], ''),
 (30, ['H'], 'H', 2, ['it won’t be long before both corporate adventurers and space tourists reach the Moon', 'measures need to be taken to protect these sites'], ''),
 (31, ['A'], 'A', 2, ['souvenir hunting and unmonitored scientific sampling'], ''),
 (32, ['F'], 'F', 2, ['remains the property of the country that sent the craft'], ''),
 (33, ['D'], 'D', 2, ['Does the US own Neil Armstrong’s famous first footprints'], ''),
 (34, ['sneezed'], 'sneezed', 2, ['someone sneezed on it'], 'x'),
 (35, ['two', '2'], 'two / 2', 2, ['for more than two years'], 'x'),
 (36, ['removed'], 'removed', 2, ['carefully removed the probe’s television camera'], 'x'),
 (37, ['analysis'], 'analysis', 2, ['One result of the analysis astonished them'], 'x'),
 (38, ['life'], 'life', 2, ['discovered evidence for life on the Moon'], 'x'),
 (39, ['C', 'D'], 'C, D  (Q39–40, either order)', 2, ['might be time to look to innovative international administrative structures'.replace('might','may')], ''),
 (40, ['C', 'D'], 'C, D  (Q39–40, either order)', 2, ['was promoted as a form of theme-park entertainment'], ''),
],
'p1r4': [
 (1, ['D'], 'D', 0, ['he intends to build five or six factories'], ''),
 (2, ['E'], 'E', 0, ['The only problem that they could foresee was possible contamination'], ''),
 (3, ['G'], 'G', 0, ['to filter water on banana plantations'], ''),
 (4, ['B'], 'B', 0, ['green glass is worth only $25 a tonne', 'is worth double that amount'], ''),
 (5, ['D'], 'D', 0, ['Current estimates of the UK market for this glass'], ''),
 (6, ['F'], 'F', 0, ['We have looked at a number of batches and it appears to do the job'], ''),
 (7, ['A'], 'A', 0, ['Backed by $1.6m from the European Union'], ''),
 (8, ['C'], 'C', 0, ['to remove the stigma of what most people would regard as an inferior product'], ''),
 (9, ['G'], 'G', 0, ['Mr Dryden has set up a network of agents round the world to sell AFM'], ''),
 (10, ['E'], 'E', 0, ['the government’s drinking water inspectorate will be asked to perform tests'], ''),
 (11, ['natural resource', 'resource'], '(natural) resource', 0, ['an increasingly scarce natural resource'], 'x'),
 (12, ['recycling industry'], 'recycling industry', 0, ['to solve a crisis in the recycling industry'], 'x'),
 (13, ['drinkable liquids', 'drinkable liquid'], 'drinkable liquids', 0, ['bottles that have already contained drinkable liquids'], 'x'),
 (14, ['sand', 'real sand'], '(real) sand', 0, ['AFM does the job better than sand'], 'x'),
 (15, ['NOT GIVEN'], 'NOT GIVEN', 1, NG, ''),
 (16, ['NOT GIVEN'], 'NOT GIVEN', 1, NG, ''),
 (17, ['NOT GIVEN'], 'NOT GIVEN', 1, NG, ''),
 (18, ['TRUE'], 'TRUE', 1, ['a vital habitat for wintering European migrant birds', 'a refuge for wintering North American migrants'], ''),
 (19, ['TRUE'], 'TRUE', 1, ['it also requires huge amounts of pesticides and fertilisers'], ''),
 (20, ['D'], 'D', 1, ['an incentive to convert existing areas of primary forest'], ''),
 (21, ['E'], 'E', 1, ['as long as the process is rigorous and offers financial gains to the producers'], ''),
 (22, ['C'], 'C', 1, ['Bird diversity in shade-grown coffee plantations rivals that found in natural forests'], ''),
 (23, ['A'], 'A', 1, ['made just $10,000 a year'], ''),
 (24, ['C'], 'C', 1, ['they have grown coffee (and cocoa) under the shade', 'more than a third of the crop is now grown in full-sun conditions'], ''),
 (25, ['B'], 'B', 1, ['a drive to increase yields by producer countries'], ''),
 (26, ['A'], 'A', 1, ['They are promoting a'], ''),
 (27, ['C'], 'C', 1, ['this system not only reduces the diversity of flora and fauna', 'may be no more diverse than full-sun farms'], ''),
 (28, ['vi'], 'vi', 2, ['The works of Aboriginal artists are now much in demand throughout the world'], ''),
 (29, ['v'], 'v', 2, ['All the works refer to the founding myth of the Aboriginal culture'], ''),
 (30, ['viii'], 'viii', 2, ['they were undoubtedly maltreated by the newcomers'], ''),
 (31, ['i'], 'i', 2, ['He was astounded by the result'], ''),
 (32, ['iv'], 'iv', 2, ['had been encouraged to reproduce on tree bark the motifs', 'supported by the churches, which helped to sell them to the public'], ''),
 (33, ['vii'], 'vii', 2, ['that moment has never ceased to exist'], ''),
 (34, ['thousands of years'], 'thousands of years', 2, ['for thousands of years Aborigines had been'], 'x'),
 (35, ['tree bark', 'bark'], '(tree) bark', 2, ['had been encouraged to reproduce on tree bark the motifs'], 'x'),
 (36, ['overseas museums'], 'overseas museums', 2, ['Aboriginal paintings began to reach overseas museums'], 'x'),
 (37, ['school walls', 'the school walls'], 'school walls', 2, ['they should decorate the school walls with ritual motifs'], 'x'),
 (38, ['B'], 'B', 2, ['it is created within and on behalf of a community who must approve it'], ''),
 (39, ['D'], 'D', 2, ['anchored to a territory marked out by its ancestors'], ''),
 (40, ['C'], 'C', 2, ['Their undeniable power prompts a dialogue'], ''),
],
'p1r5': [
 (1, ['B'], 'B', 0, ['inside which they farm a fungus that is their primary food source', 'This must be kept at exactly 30.5°C'], ''),
 (2, ['D'], 'D', 0, ['because an air-conditioning plant didn’t have to be imported'], ''),
 (3, ['C'], 'C', 0, ['with its fantastically hot summers and fantastically cold winters'], ''),
 (4, ['C'], 'C', 0, ['the temperature of the building has generally stayed between 23°C and 25°C'], ''),
 (5, ['A'], 'A', 0, ['he hoped plants would grow wild in the atrium and pigeons and bats would move into it'], ''),
 (6, ['ceiling vents'], 'ceiling vents', 0, ['it is drawn out via ceiling vents'], 'x'),
 (7, ['brick chimneys', 'chimneys', '48 brick chimneys', 'forty-eight brick chimneys'], '(forty-eight) brick chimneys', 0, ['finally exits through forty-eight brick chimneys'], 'x'),
 (8, ['cement arches', 'arches'], '(cement) arches', 0, ['all the windows are screened by cement arches'], 'x'),
 (9, ['big fans'], 'big fans', 0, ['big fans flush air through the building seven times an hour'], 'x'),
 (10, ['small heaters', 'heaters'], '(small) heaters', 0, ['there are small heaters in the vents'], 'x'),
 (11, ['entrances', 'the entrances', 'elevators', 'fan covers', 'the fan covers'], 'entrances / elevators / fan covers (Q11–13, any order)', 0, ['The design of the entrances is based on'], 'x'),
 (12, ['entrances', 'the entrances', 'elevators', 'fan covers', 'the fan covers'], 'entrances / elevators / fan covers (Q11–13, any order)', 0, ['Elevators are designed to look like the mineshaft cages'], 'x'),
 (13, ['entrances', 'the entrances', 'elevators', 'fan covers', 'the fan covers'], 'entrances / elevators / fan covers (Q11–13, any order)', 0, ['The shape of the fan covers'], 'x'),
 (14, ['v'], 'v', 1, ['But the company’s name may itself simply be an example of clever marketing'], ''),
 (15, ['i'], 'i', 1, ['A volunteer lies in an fMRI machine and is shown images or video clips'], ''),
 (16, ['ix'], 'ix', 1, ['American companies have become more open about their use of neuromarketing'], ''),
 (17, ['viii'], 'viii', 1, ['Of course, focus groups and surveys are flawed too'], ''),
 (18, ['iii'], 'iii', 1, ['An unpublished study of attitudes towards two well-known cola drinks'], ''),
 (19, ['vi'], 'vi', 1, ['could make a fortune'], ''),
 (20, ['F'], 'F', 1, ['to ensure that advertising falls within those bounds'], ''),
 (21, ['D'], 'D', 1, ['Neuromarketing is a tool to amplify these trends'], ''),
 (22, ['A'], 'A', 1, ['then that subsidises the cost of the equipment'], ''),
 (23, ['brands'], 'brands', 1, ['how customers respond to products, brands and advertising'], 'x'),
 (24, ['dishonest'], 'dishonest', 1, ['people do not always tell opinion pollsters the truth'], ''),
 (25, ['subconscious'], 'subconscious', 1, ['This provides clues to the subject’s subconscious thought patterns'], 'x'),
 (26, ['children'], 'children', 1, ['That is especially true of children'], 'x'),
 (27, ['NOT GIVEN'], 'NOT GIVEN', 2, NG, ''),
 (28, ['TRUE'], 'TRUE', 2, ['most of them ferns and some of them unique to the island'], ''),
 (29, ['FALSE'], 'FALSE', 2, ['he concluded that the island had suffered some natural calamity'], ''),
 (30, ['TRUE'], 'TRUE', 2, ['With sailors planting several thousand trees a year'], ''),
 (31, ['NOT GIVEN'], 'NOT GIVEN', 2, NG, ''),
 (32, ['FALSE'], 'FALSE', 2, ['including those of two species that especially liked the place'], ''),
 (33, ['B'], 'B', 2, ['squeezing out the island’s endemic plants'], ''),
 (34, ['F'], 'F', 2, ['the introduced species have been a roaring success'], ''),
 (35, ['D'], 'D', 2, ['Conventional ecological theory says that complex ecosystems such as cloud forests can emerge only through evolutionary processes'], ''),
 (36, ['G'], 'G', 2, ['The new arrivals may just be an adornment, with little structural importance'], ''),
 (37, ['A'], 'A', 2, ['may in places be little more than the overgrown gardens of past rainforest civilisations'], ''),
 (38, ['B'], 'B', 2, ['ecologists are missing out on the study of a great enigma'], ''),
 (39, ['A'], 'A', 2, ['If alien, did they come with the plant on which they feed or discover it on arrival?'], ''),
 (40, ['B'], 'B', 2, ['the most artificial rainforest in the world could tell us more about rainforest ecology'], ''),
],
'p1r6': [
 (1, ['transportation'], 'transportation', 0, ['makes transportation less difficult'], 'x'),
 (2, ['pharmaceuticals'], 'pharmaceuticals', 0, ['to preserve other sorts of material, such as pharmaceuticals'], 'x'),
 (3, ['manuscripts', 'valuable manuscripts'], '(valuable) manuscripts', 0, ['Even valuable manuscripts that had been water damaged'], 'x'),
 (4, ['sublimation'], 'sublimation', 0, ['This is called'], 'x'),
 (5, ['simple drying', 'simple drying techniques'], 'simple drying (techniques)', 0, ['whereas simple drying techniques can only remove 90-95%'], 'x'),
 (6, ['freeze-drying chamber', 'freeze drying chamber', 'chamber', 'drying chamber'], '(freeze-drying) chamber', 0, ['The material to be preserved is placed in a freeze-drying chamber'], 'x'),
 (7, ['shelves'], 'shelves', 0, ['The heating units apply a small amount of heat to the shelves in the chamber'], 'x'),
 (8, ['freezing coil'], 'freezing coil', 0, ['The water vapour condenses onto the freezing coil'], 'x'),
 (9, ['refrigerator compressor', 'compressor'], '(refrigerator) compressor', 0, ['connected to a freezing coil and refrigerator compressor'], 'x'),
 (10, ['enzymes'], 'enzymes', 0, ['the enzymes which occur naturally in food cannot cause ripening without water'], 'x'),
 (11, ['composition'], 'composition', 0, ['the composition and structure of the material is not significantly changed'], 'x'),
 (12, ['overheating'], 'overheating', 0, ['This time is necessary to avoid overheating'], 'x'),
 (13, ['high altitudes', 'high altitude', 'mountain peaks'], 'high altitudes', 0, ['The extremely cold temperatures and low pressure at those high altitudes'], 'x'),
 (14, ['NOT GIVEN'], 'NOT GIVEN', 1, NG, ''),
 (15, ['TRUE'], 'TRUE', 1, ['agrochemical pollution in the farming lowlands'], ''),
 (16, ['TRUE'], 'TRUE', 1, ['the cutting down of hedgerows on farmland has contributed to habitat isolation'], ''),
 (17, ['NOT GIVEN'], 'NOT GIVEN', 1, NG, ''),
 (18, ['NOT GIVEN'], 'NOT GIVEN', 1, NG, ''),
 (19, ['FALSE'], 'FALSE', 1, ['much of this has been spectacularly colonised'], ''),
 (20, ['woodland species'], 'woodland species', 1, ['Those that do best tend to be woodland species'], 'x'),
 (21, ['exotic flowers'], 'exotic flowers', 1, ['especially with exotic flowers extending the nectar season'], 'x'),
 (22, ['domestic cats', 'cats', 'the domestic cats'], '(domestic) cats', 1, ['only the millions of domestic cats may spoil the scene'], 'x'),
 (23, ['81', 'eighty-one', 'eighty one'], '81', 1, ['increased from 17 to an amazing 81'], 'x'),
 (24, ['C', 'E', 'G'], 'C, E, G  (Q24–26, any order)', 1, ['contact with wildlife close to home can help to reduce stress and anger'], ''),
 (25, ['C', 'E', 'G'], 'C, E, G  (Q24–26, any order)', 1, ['ponds and wetlands to contain storm water runoff'], ''),
 (26, ['C', 'E', 'G'], 'C, E, G  (Q24–26, any order)', 1, ['The canopy of the urban forest is filtering air pollution'], ''),
 (27, ['C'], 'C', 1, ['if we work with wildlife, then wildlife will work for us'], ''),
 (28, ['iii'], 'iii', 2, ['all have been based on the'], ''),
 (29, ['vi'], 'vi', 2, ['The essence of their new theory is that the brain'], ''),
 (30, ['ii'], 'ii', 2, ['they become fatigued even though lactic acid levels remain low'], ''),
 (31, ['vii'], 'vii', 2, ['Noakes conducted an experiment with seven cyclists'], ''),
 (32, ['viii'], 'viii', 2, ['But his team found exactly the opposite'], ''),
 (33, ['iv'], 'iv', 2, ['To Noakes, this was strong evidence that the old theory was wrong'], ''),
 (34, ['C'], 'C', 2, ['Lactic acid is a by-product of exercise'], ''),
 (35, ['A'], 'A', 2, ['they either run out of fuel or oxygen'], ''),
 (36, ['B'], 'B', 2, ['it creates the distressing sensations we interpret as unbearable muscle fatigue'], ''),
 (37, ['C'], 'C', 2, ['The governor constantly monitors physiological signals from the muscles'], ''),
 (38, ['B'], 'B', 2, ['the central regulator evaluates the planned workout, and sets a pacing strategy accordingly'], ''),
 (39, ['A'], 'A', 2, ['its accumulation is often cited as a cause of fatigue'], ''),
 (40, ['B'], 'B', 2, ['St Clair Gibson believes there is a good reason why our bodies are designed to keep something back'], ''),
],
}

# any-order groups: repeated answers only score once (lib/marking.ts `pool`)
POOLS = {'p1r3': [[39, 40]], 'p1r5': [[11, 12, 13]], 'p1r6': [[24, 25, 26]]}

problems = []
for pid, rows in PAPERS.items():
    t = json.load(open(f'content/tests/{pid}.json'))
    text = []
    for s in t['sections']:
        paras = s['passage']['paras']
        text.append(' '.join(plain(p['t'] if isinstance(p, dict) else p) for p in paras))
    sents = [sentences(x) for x in text]
    key, ev = {}, {}
    nums = sorted(r[0] for r in rows)
    assert nums == list(range(1, t['total'] + 1)), (pid, 'numbering')
    for q, acc, disp, sec, needles, kind in rows:
        # the section the question sits in must be the section the evidence comes from
        qsec = next(i for i, s in enumerate(t['sections']) if q in s['qs'])
        if qsec != sec: problems.append((pid, q, 'section mismatch'))
        key[str(q)] = {'accept': acc, 'display': disp}
        if needles is NG:
            ev[str(q)] = {'s': sec, 't': [], 'k': 'none'}
            continue
        lines = []
        for n in needles:
            hit = [x for x in sents[sec] if n in x]
            if not hit:
                problems.append((pid, q, 'needle not found: ' + n))
                continue
            if hit[0] not in lines: lines.append(hit[0])
        e = {'s': sec, 't': lines}
        if kind == 'x': e['k'] = 'exact'
        ev[str(q)] = e
    for pool in POOLS.get(pid, []):
        for q in pool:
            key[str(q)]['pool'] = [str(x) for x in pool]
    if not problems:
        json.dump(key, open(f'content/keys/{pid}.json', 'w'), ensure_ascii=False, indent=1)
        json.dump(ev, open(f'content/evidence/{pid}.json', 'w'), ensure_ascii=False, indent=1)
        print('wrote', pid, len(key))

if problems:
    for p in problems: print('PROBLEM', p)
    raise SystemExit('nothing written for papers after the first problem')

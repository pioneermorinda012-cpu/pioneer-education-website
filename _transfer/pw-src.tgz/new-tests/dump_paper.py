"""Write a readable text version of a paper: passages with sentence numbers, then questions."""
import json, re, html, sys, os

def plain(x):
    return re.sub(r'\s+', ' ', html.unescape(re.sub(r'<[^>]+>', ' ', str(x)))).strip()

def cell(c):
    return plain(c['t'] if isinstance(c, dict) else c)

for id in sys.argv[1:]:
    t = json.load(open(f'content/tests/{id}.json')); KEY = json.load(open(f'content/keys/{id}.json'))
    out = [f'##### {id} {t["name"]} total={t["total"]}']
    for si, s in enumerate(t['sections']):
        out.append(f'\n================ SECTION {si} {s["label"]} qs={s["qs"][0]}-{s["qs"][-1]}')
        ps = s.get('passage')
        if ps:
            out.append('TITLE: ' + plain(ps.get('title', '')) + ' | ' + plain(ps.get('sub', '')))
            for p in ps['paras']:
                if isinstance(p, dict):
                    out.append(f"[{p.get('l','')}] {plain(p['t'])}")
                else:
                    out.append('[] ' + plain(p))
        for g in s['groups']:
            out.append(f"\n--- {plain(g.get('title',''))} :: {plain(g.get('instr',''))}")
            for k in ('heading', 'example', 'bankTitle'):
                if g.get(k): out.append(f'{k}: {plain(g[k])}')
            if g.get('bank'):
                out.append('BANK: ' + ' | '.join(f'{a} {plain(b)}' for a, b in g['bank']))
            if g.get('opts'):
                out.append('OPTS: ' + ', '.join(o if isinstance(o, str) else o.get('l', '') for o in g['opts']))
            for k in ('pick', 'multi', 'choose'):
                if k in g: out.append(f'{k}: {g[k]}')
            gapq=[n for n in s['qs'] if '{{%d}}'%n in json.dumps(g)]
            if gapq: out.append('KEYS: '+'; '.join(f"{n}={KEY.get(str(n),{}).get('display')}" for n in gapq))
            for l in g.get('lines', []) or []:
                out.append('  ' + (plain(l['t']) if isinstance(l, dict) else plain(l)))
            for r in g.get('table', []) or []:
                out.append('  | ' + ' | '.join(cell(c) for c in r))
            for q in g.get('questions', []) or []:
                extra = {k: v for k, v in q.items() if k not in ('n', 'stem', 'opts')}
                out.append(f"  Q{q['n']} [KEY {KEY.get(str(q['n']),{}).get('display')}]: {plain(q.get('stem',''))} {('OPTS: ' + ' / '.join(chr(65+i)+'. '+plain(o) for i,o in enumerate(q['opts']))) if q.get('opts') else ''} {extra if extra else ''}")
            other = {k: v for k, v in g.items() if k not in ('title','instr','heading','example','bankTitle','bank','opts','lines','table','questions','compact')}
            if other: out.append('OTHER: ' + json.dumps(other, ensure_ascii=False)[:400])
    os.makedirs('new-tests/_dumps', exist_ok=True)
    open(f'new-tests/_dumps/{id}.txt', 'w').write('\n'.join(out))
    print(id, len('\n'.join(out)))
